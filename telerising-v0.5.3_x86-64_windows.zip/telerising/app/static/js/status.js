$(document).ready(function() {

    // Change root location
    $("#go-to-home").prop("href", window.location.href.replace("#", ""));

    $("#custom-submission").hide();
    $(".card").fadeIn(500).prop("hidden", false)

    $.each(test, function(key, item) {

        // Show/hide provider properties

        $("#" + key + "-info").attr("fill", "blue");
        $("#" + key + "-submission").hide();
        $("#" + key + "-advanced-message").hide();
        $("#" + key + "-account-message").hide();

        if( test[key]['status'] === "ERROR") {
            $("#" + key + "-features").hide();
            $("#" + key + "-message-text").text(test[key]['message']);
            $("#" + key + "-message").prop("style", "color: red; margin-top: 10px;");
            $("#" + key + "-message").hide().prop("hidden", false).show();
            $("#" + key + "-status").text("ERROR").prop("style", "color: red;");
            $("#" + key + "-card-header").prop("style", "background-color: red;");
        };
        if( test[key]['availability']['live'] === true ) {
            $("#" + key + "-live").prop("hidden", false);
        };
        if( test[key]['availability']['pvr'] === true ) {
            $("#" + key + "-pvr").prop("hidden", false);
        };
        if( test[key]['availability']['vod'] === true ) {
            $("#" + key + "-vod").prop("hidden", false);
        };


        // Create Live TV playlist URL

        var input = document.getElementById(key + "-playlist");
        input.value = window.location.href + "api/" + key + "/file/channels.m3u";
        input.value = input.value.replace("#", "");

        if( $("#" + key + "-code-input").val() != "" ) {
            input.value = input.value + "?code=" + $("#" + key + "-code-input").val();
        }

        $("#" + key + "-enable-favorites").on("change", function() {
            if( $("#" + key + "-enable-favorites").is(":checked") ) {
                input.value = $("#" + key + "-playlist").val().replace("channels.m3u", "favorites.m3u");
            } else {
                input.value = $("#" + key + "-playlist").val().replace("favorites.m3u", "channels.m3u");
            }
        });

        $("#" + key + "-enable-pipe").on("change", function() {
            if( $("#" + key + "-enable-pipe").is(":checked") && $("#" + key + "-code-input").val() === "" ) {
                input.value = $("#" + key + "-playlist").val() + "?ffmpeg=true";
            } else if ( $("#" + key + "-enable-pipe").is(":checked") && $("#" + key + "-code-input").val() != "" ) {
                input.value = $("#" + key + "-playlist").val() + "&ffmpeg=true";
            } else if ( !$("#" + key + "-enable-pipe").is(":checked") && $("#" + key + "-code-input").val() != "" ) {
                input.value = $("#" + key + "-playlist").val().replace("&ffmpeg=true", "");
            } else if ( !$("#" + key + "-enable-pipe").is(":checked") && $("#" + key + "-code-input").val() === "" ) {
                input.value = $("#" + key + "-playlist").val().replace("?ffmpeg=true", "");
            }
        });

        $("#" + key + "-playlist-copy").on("click", function() {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($("#" + key + "-playlist").val()).select();
            document.execCommand("copy");
            $temp.remove();
            $("#" + key + "-playlist-copy").text("Copied!");
            $("#" + key + "-playlist-copy").prop("disabled", true);
            window.setTimeout( function() {
                $("#" + key + "-playlist-copy").text("Copy");
                $("#" + key + "-playlist-copy").prop("disabled", false);
            }, 3000);
        });


        // Switch to Live/PVR playlist

        $("#" + key + "-m3u-pvr").on("click", function() {
            $("#" + key + "-m3u-live").prop("checked", false);
            if( $("#" + key + "-enable-favorites").is(":checked") ) {
                input.value = $("#" + key + "-playlist").val().replace("favorites.m3u", "recordings.m3u");
            } else {
                input.value = $("#" + key + "-playlist").val().replace("channels.m3u", "recordings.m3u");
            }
            $("#" + key + "-enable-favorites").prop("disabled", true);
        });

        $("#" + key + "-m3u-live").on("click", function() {
            $("#" + key + "-m3u-pvr").prop("checked", false);
            if( $("#" + key + "-enable-favorites").is(":checked") ) {
                input.value = $("#" + key + "-playlist").val().replace("recordings.m3u", "favorites.m3u");
            } else {
                input.value = $("#" + key + "-playlist").val().replace("recordings.m3u", "channels.m3u");
            }
            $("#" + key + "-enable-favorites").prop("disabled", false);
        });


        // Click on provider card header

        $("#" + key + "-card-header").on("click", function() {
            $(".card-body").slideUp(500);
            $(".card-link").addClass("stretched-link");
            if( $("#" + key + "-body").is(":hidden") ) {
                $("#" + key + "-body").slideDown(500);
                $("#" + key + "-link").removeClass("stretched-link");
            } else {
                $("#" + key + "-body").slideUp(500);
                $("#" + key + "-link").addClass("stretched-link");
            };
        });


        // Click on file button inside of provider card body

        $("#" + key + "-sts").on("click", function() {
            $("#" + key + "-sts").removeClass("btn-outline-dark").addClass("btn-dark");
            $("#" + key + "-file").removeClass("btn-dark").addClass("btn-outline-dark");
            $("#" + key + "-settings").removeClass("btn-dark").addClass("btn-outline-dark");
            $("#" + key + "-card-status").slideDown(500);
            $("#" + key + "-card-files").slideUp(500);
            $("#" + key + "-card-settings").slideUp(500);
        });


        // Click on file button inside of provider card body

        $("#" + key + "-file").on("click", function() {
            $("#" + key + "-sts").removeClass("btn-dark").addClass("btn-outline-dark");
            $("#" + key + "-file").removeClass("btn-outline-dark").addClass("btn-dark");
            $("#" + key + "-settings").removeClass("btn-dark").addClass("btn-outline-dark");
            $("#" + key + "-card-status").slideUp(500);
            $("#" + key + "-card-files").slideDown(500);
            $("#" + key + "-card-settings").slideUp(500);
        });


        // Click on settings button inside of provider card body

        $("#" + key + "-settings").on("click", function() {
            $("#" + key + "-sts").removeClass("btn-dark").addClass("btn-outline-dark");
            $("#" + key + "-file").removeClass("btn-dark").addClass("btn-outline-dark");
            $("#" + key + "-settings").removeClass("btn-outline-dark").addClass("btn-dark");
            $("#" + key + "-card-status").slideUp(500);
            $("#" + key + "-card-files").slideUp(500);
            $("#" + key + "-card-settings").slideDown(500);
        });


        // Click on manifest button inside of provider/settings card body

        $("#" + key + "-manifest").on("click", function() {
            $("#" + key + "-manifest").removeClass("btn-outline-secondary").addClass("btn-secondary");
            $("#" + key + "-advanced").removeClass("btn-secondary").addClass("btn-outline-secondary");
            $("#" + key + "-account-info").removeClass("btn-secondary").addClass("btn-outline-secondary");
            $("#" + key + "-card-settings-manifest").slideDown(500);
            $("#" + key + "-card-settings-advanced").slideUp(500);
            $("#" + key + "-card-settings-account-info").slideUp(500);
        });


        // Click on advanced button inside of provider/settings card body

        $("#" + key + "-advanced").on("click", function() {
            $("#" + key + "-manifest").removeClass("btn-secondary").addClass("btn-outline-secondary");
            $("#" + key + "-advanced").removeClass("btn-outline-secondary").addClass("btn-secondary");
            $("#" + key + "-account-info").removeClass("btn-secondary").addClass("btn-outline-secondary");
            $("#" + key + "-card-settings-manifest").slideUp(500);
            $("#" + key + "-card-settings-advanced").slideDown(500);
            $("#" + key + "-card-settings-account-info").slideUp(500);
        });


        // Click on account button inside of provider/settings card body

        $("#" + key + "-account-info").on("click", function() {
            $("#" + key + "-manifest").removeClass("btn-secondary").addClass("btn-outline-secondary");
            $("#" + key + "-advanced").removeClass("btn-secondary").addClass("btn-outline-secondary");
            $("#" + key + "-account-info").removeClass("btn-outline-secondary").addClass("btn-secondary");
            $("#" + key + "-card-settings-manifest").slideUp(500);
            $("#" + key + "-card-settings-advanced").slideUp(500);
            $("#" + key + "-card-settings-account-info").slideDown(500);
        });


        // Remove provider setup

        var countdown = 5;
        $("#" + key + "-submit-delete-form").on("click", function() {
            if( countdown > 0) {
                countdown -= 1;
            };
            if( countdown === 0 ) {
                $.ajax({
                    type: "GET",
                    url: "api/remove/" + key,
                    success: function(data) {
                        if(data.success) {
                            $("#" + key + "-submit-delete-form").prop("disabled", true);
                            $("#" + key + "-submit-delete-form").text("Provider deleted!")
                            window.setTimeout( function() {
                                window.location = "/";
                            }, 1000);
                        }
                    },
                    error: function() {
                        $("#" + key + "-submit-delete-form").prop("disabled", true);
                        $("#" + key + "-submit-delete-form").text("Unable to retrieve API status");
                    }
                });
            } else {
                $("#" + key + "-submit-delete-form").text("Remove provider (" + countdown + ")");
            }
        });


        // Update account password

        $("#" + key + "-submit-credentials").on("click", function() {
            if( !$("#" + key + "-account-message").is(":hidden") ) {
                $("#" + key + "-account-message").prop("style", "margin-top: 3px; opacity: 0.5;");
            }
            $("#" + key + "-submit-credentials").prop("disabled", true);
            $.ajax({
                type: "POST",
                url: "api/" + key + "/save/account_pw",
                data: {
                    "pw": $("#" + key + "-pw-input").val()
                },
                success: function(data) {
                    if(data.success) {
                        UpdateSession();
                        $("#" + key + "-account-message-text").text("Account password updated successfully.");
                        $("#" + key + "-account-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: #00aa00;");
                    } else {
                        $("#" + key + "-account-message-text").text(data.message);
                        $("#" + key + "-account-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                    }
                },
                error: function() {
                    $("#" + key + "-account-message-text").text("Failed to retrieve API status");
                    $("#" + key + "-account-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                }
            });
            $("#" + key + "-submit-credentials").prop("disabled", false);
            window.setTimeout( function() {
                $("#" + key + "-account-message").slideUp(500);
            }, 3000);
        });


        // Update server settings

        $("#" + key + "-update-server").on("click", function() {
            if( !$("#" + key + "-advanced-message").is(":hidden") ) {
                $("#" + key + "-advanced-message").prop("style", "margin-top: 3px; opacity: 0.5;");
            }
            $("#" + key + "-update-server").prop("disabled", true);
            $.ajax({
                type: "POST",
                url: "api/" + key + "/save/server",
                data: {
                    "name": $("#" + key + "-server-selection").val()
                },
                success: function(data) {
                    if(data.success) {
                        $("#" + key + "-advanced-message-text").text("Server updated successfully.");
                        $("#" + key + "-advanced-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: #00aa00;");
                    } else {
                        $("#" + key + "-advanced-message-text").text(data.message);
                        $("#" + key + "-advanced-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                    }
                },
                error: function() {
                    $("#" + key + "-advanced-message-text").text("Failed to retrieve API status");
                    $("#" + key + "-advanced-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                }
            });
            $("#" + key + "-update-server").prop("disabled", false);
            window.setTimeout( function() {
                $("#" + key + "-advanced-message").slideUp(500);
            }, 3000);
        });


        // Update API code

        $("#" + key + "-update-code").on("click", function() {
            if( !$("#" + key + "-advanced-message").is(":hidden") ) {
                $("#" + key + "-advanced-message").prop("style", "margin-top: 3px; opacity: 0.5;");
            }
            $("#" + key + "-update-code").prop("disabled", true);
            $.ajax({
                type: "POST",
                url: "api/" + key + "/save/api_code",
                data: {
                    "value": $("#" + key + "-code-input").val()
                },
                success: function(data) {
                    if(data.success) {
                        $("#" + key + "-advanced-message-text").text("API code updated successfully.");
                        $("#" + key + "-advanced-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: #00aa00;");
                        if( $("#" + key + "-code-input").val() === "" ) {
                            input.value = $("#" + key + "-playlist").val().split("?")[0];
                        } else {
                            input.value = $("#" + key + "-playlist").val().split("?")[0] + "?code=" + $("#" + key + "-code-input").val();
                        }
                        $("#" + key + "-enable-pipe").prop("checked", false);
                    } else {
                        $("#" + key + "-advanced-message-text").text(data.message);
                        $("#" + key + "-advanced-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                    }
                },
                error: function() {
                    $("#" + key + "-advanced-message-text").text("Failed to retrieve API status");
                    $("#" + key + "-advanced-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                }
            });
            $("#" + key + "-update-code").prop("disabled", false);
            window.setTimeout( function() {
                $("#" + key + "-advanced-message").slideUp(500);
            }, 3000);
        });


        // Update Youth Protection PIN

        $("#" + key + "-update-pin").on("click", function() {
            if( !$("#" + key + "-account-message").is(":hidden") ) {
                $("#" + key + "-account-message").prop("style", "margin-top: 3px; opacity: 0.5;");
            }
            $("#" + key + "-update-pin").prop("disabled", true);
            $.ajax({
                type: "POST",
                url: "api/" + key + "/save/yp_code",
                data: {
                    "value": $("#" + key + "-pin-input").val()
                },
                success: function(data) {
                    $("#" + key + "-account-message-text").text(data.message);
                    if(data.success) {
                        $("#" + key + "-account-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: #00aa00;");
                    } else {
                        $("#" + key + "-account-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                    }
                },
                error: function() {
                    $("#" + key + "-account-message-text").text("Failed to retrieve API status");
                    $("#" + key + "-account-message").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                }
            });
            $("#" + key + "-update-pin").prop("disabled", false);
            window.setTimeout( function() {
                $("#" + key + "-account-message").slideUp(500);
            }, 3000);
        });


        // If audio type is changed, avoid duplicated entries

        $("#" + key + "-A1").on("change", function() {
            if( $("#" + key + "-A1").val() === $("#" + key + "-A2").val() ) {
                $("#" + key + "-A2None").prop("selected", true)
            }
        });

        $("#" + key + "-A2").on("change", function() {
            if( $("#" + key + "-A1").val() === $("#" + key + "-A2").val() ) {
                if( $("#" + key + "-A2").val() === "aac1" ) {
                    $("#" + key + "-A1Stereo2").prop("selected", true)
                } else {
                    $("#" + key + "-A1Stereo1").prop("selected", true)
                }
            }
        });


        // If manifest type is changed, also change the available audio profiles

        $("#" + key + "-manifest-selection").on("change", function() {
            if( $("#" + key + "-manifest-selection").val() === "hls5" ) {
                if( $("#" + key + "-A1").val() === "dd1" ) {
                    if( $("#" + key + "-A2").val() === "aac1" ) {
                        $("#" + key + "-A1Stereo2").prop("selected", true)
                    } else {
                        $("#" + key + "-A1Stereo1").prop("selected", true)
                    }
                }
                if( $("#" + key + "-A2").val() === "dd1" ) {
                    if( $("#" + key + "-A1").val() === "aac1" ) {
                        $("#" + key + "-A2None").prop("selected", true)
                    } else {
                        $("#" + key + "-A2Stereo1").prop("selected", true)
                    }
                }
                $("." + key + "-audio").prop("disabled", false);
                $("." + key + "-dd").prop("disabled", true);
            } else if( $("#" + key + "-manifest-selection").val() === "hls7" ) {
                $("." + key + "-audio").prop("disabled", false);
                $("." + key + "-dd").prop("disabled", false);
            }
        });


        // Update manifest settings

        $("#" + key + "-submit-provider-form").on("click", function() {
            if( !$("#" + key + "-submission").is(":hidden") ) {
                $("#" + key + "-submission").prop("style", "margin-top: 3px; opacity: 0.5;");
            }
            $("#" + key + "-submit-provider-form").prop("disabled", true);
            $("#" + key + "-submit-provider-form").text("Saving...");
            $.ajax({
                type: "POST",
                url: "api/" + key + "/save/manifest",
                data: {
                    "manifest_type": $("#" + key + "-manifest-selection").val(),
                    "bw": $("#" + key + "-bw-selection").val(),
                    "audio1": $("#" + key + "-A1").val(),
                    "audio2": $("#" + key + "-A2").val()
                },
                success: function(data) {
                    if(data.success) {
                        $("#" + key + "-submission-message").text("Settings updated successfully!");
                        $("#" + key + "-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: #00aa00;");
                    } else {
                        $("#" + key + "-submission-message").text(data.message);
                        $("#" + key + "-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                    }
                    $("#" + key + "-submit-provider-form").text("Save settings");
                    $("#" + key + "-submit-provider-form").prop("disabled", false);
                },
                error: function() {
                    $("#" + key + "-submission-message").text("Unable to retrieve API status");
                    $("#" + key + "-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                    $("#" + key + "-submit-provider-form").text("Save settings");
                    $("#" + key + "-submit-provider-form").prop("disabled", false);
                }
            });
            window.setTimeout( function() {
                $("#" + key + "-submission").slideUp(500);
            }, 3000);
        });


        // Session update

        $("#" + key + "-update").on("click", function() {
            UpdateSession();
        });

        function UpdateSession() {

            $("#" + key + "-message").slideUp(300);
            $("#" + key + "-update").prop("disabled", true);
            $("#" + key + "-update").text("Updating session...");
            $("#" + key + "-card-header").prop("style", "background-color: grey;")
            $("#" + key + "-status").text("Checking...").prop("style", "color: grey;");
            $.ajax({
                type: "POST",
                url: "api/session",
                data: {
                    "id": key
                },
                success: function(info) {
                    if( info.success === true ) {
                        $("#" + key + "-features").show();
                        $("#" + key + "-status").text("OK").prop("style", "color: #00aa00;");
                        $("#" + key + "-card-header").prop("style", "background-color: #00aa00;");
                        $("#" + key + "-message").prop("style", "color: #00aa00; margin-top: 10px;");
                        if( info['data']['availability']['live'] === true ) {
                            $("#" + key + "-live").prop("hidden", false);
                        } else {
                            $("#" + key + "-live").prop("hidden", true);
                        };
                        if( info['data']['availability']['live_mode'] === "live" ) {
                            $("#" + key + "-live-text").text("Live TV");
                        } else if ( test[key]['availability']['live_mode'] === "pvr" ) {
                            $("#" + key + "-live-text").text("Live TV (via PVR)");
                        };
                        if( info['data']['availability']['pvr'] === true ) {
                            $("#" + key + "-pvr").prop("hidden", false);
                        } else {
                            $("#" + key + "-pvr").prop("hidden", true);
                        };
                        if( info['data']['availability']['vod'] === true ) {
                            $("#" + key + "-vod").prop("hidden", false);
                        } else {
                            $("#" + key + "-vod").prop("hidden", true);
                        };
                    } else {
                        $("#" + key + "-features").hide();
                        $("#" + key + "-live").prop("hidden", true);
                        $("#" + key + "-pvr").prop("hidden", true);
                        $("#" + key + "-vod").prop("hidden", true);
                        $("#" + key + "-message").prop("style", "color: red; margin-top: 10px;");
                        $("#" + key + "-status").text("ERROR").prop("style", "color: red;");
                        $("#" + key + "-card-header").prop("style", "background-color: red;");
                    }
                    $("#" + key + "-account-text").text(info['data']['info']['type']);
                    $("#" + key + "-message-text").text(info['data']['message']);
                    $("#" + key + "-message").hide().prop("hidden", false).slideDown(300);
                    $("#" + key + "-update").prop("disabled", false);
                    $("#" + key + "-update").text("Update session");
                    if( info.success === true ) {
                        window.setTimeout( function() {
                            $("#" + key + "-message").slideUp(500);
                        }, 3000);
                    }
                },
                error: function() {
                    $("#" + key + "-features").hide();
                    $("#" + key + "-live").prop("hidden", true);
                    $("#" + key + "-pvr").prop("hidden", true);
                    $("#" + key + "-vod").prop("hidden", true);
                    $("#" + key + "-account-text").text("Unknown");
                    $("#" + key + "-message").prop("style", "color: red; margin-top: 10px;");
                    $("#" + key + "-status").text("ERROR").prop("style", "color: red;");
                    $("#" + key + "-card-header").prop("style", "background-color: red;");
                    $("#" + key + "-message-text").text("Unable to retrieve API status");
                    $("#" + key + "-message").hide().prop("hidden", false).slideDown(300);
                    $("#" + key + "-update").prop("disabled", false);
                    $("#" + key + "-update").text("Update session");
                }
            });
        }
    });


    // Click on settings card header

    $("#settings-card-header").on("click", function() {
        $(".card-body").slideUp(500);
        $(".card-link").addClass("stretched-link");
        if( $("#settings-body").is(":hidden") ) {
            $("#settings-body").slideDown(500);
            $("#settings-link").removeClass("stretched-link");
        } else {
            $("#settings-body").slideUp(500);
            $("#settings-link").addClass("stretched-link");
        };
    });


    // Go to setup page

    $("#add-provider").on("click", function() {
        window.location = "/setup";
    });


    // Save custom IP address

    $("#submit-address-path").on("click", function() {
        if( !$("#custom-submission").is(":hidden") ) {
            $("#custom-submission").prop("style", "margin-top: 3px; opacity: 0.5;");
        }
        $("#submit-address-path").prop("disabled", true);
        $.ajax({
            type: "POST",
            url: "api/save_settings/custom_ip",
            data: {
              "ip": $("#custom-path").val()
            },
            success: function(data) {
                $("#custom-submission-message").text(data.message);
                if(data.success) {
                    $("#custom-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: #00aa00;");
                } else {
                    $("#custom-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                }
            },
            error: function() {
                $("#custom-submission-message").text("Unable to retrieve API status");
                $("#custom-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
            }
        });
        $("#submit-address-path").prop("disabled", false);
        window.setTimeout( function() {
            $("#custom-submission").slideUp(500);
        }, 3000);
    });


    // Save custom port

    $("#submit-port").on("click", function() {
        $("#submit-port").prop("disabled", true);
        $("#submit-port").text("Restarting...");
        $.ajax({
            type: "POST",
            url: "api/save_settings/custom_port",
            data: {
              "port": $("#custom-port").val()
            }
        });
        $.ajax({
            type: "GET",
            url: "api/restart"
        });
        window.setTimeout( function() {
            var custom_port = $("#custom-port").val();
            if( custom_port === "" ) {
                var custom_port = "5000";
            }
            window.location = "http://" + window.location.hostname + ":" + custom_port;
        }, 1000);
    });


    // Save custom ffmpeg path

    $("#submit-ffmpeg-path").on("click", function() {
        if( !$("#custom-submission").is(":hidden") ) {
            $("#custom-submission").prop("style", "margin-top: 3px; opacity: 0.5;");
        }
        $("#submit-ffmpeg-path").prop("disabled", true);
        $.ajax({
            type: "POST",
            url: "api/save_settings/ffmpeg_path",
            data: {
              "ffmpeg_path": $("#custom-ffmpeg-path").val()
            },
            success: function(data) {
                $("#custom-submission-message").text(data.message);
                if(data.success) {
                    $("#custom-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: #00aa00;");
                } else {
                    $("#custom-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
                }
            },
            error: function() {
                $("#custom-submission-message").text("Unable to retrieve API status");
                $("#custom-submission").slideDown(500).prop("style", "margin-top: 3px; opacity: 1; color: red;");
            }
        });
        $("#submit-ffmpeg-path").prop("disabled", false);
        window.setTimeout( function() {
            $("#custom-submission").slideUp(500);
        }, 3000);
    });


    // Start: Show card body of first provider setup

    $(".card-body").hide();
    $(".card-files").hide();
    $(".card-settings").hide();
    $(".card").fadeIn(500).prop("hidden", false);
    $("#" + Object.keys(test)[0] + "-link").removeClass("stretched-link");
    $("#" + Object.keys(test)[0] + "-body").slideDown(500);
});