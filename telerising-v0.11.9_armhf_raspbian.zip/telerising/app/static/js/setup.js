$(document).ready(function() {

    // Change root location
    $("#go-to-home").prop("href", window.location.href.replace(new RegExp('/setup$'), ""));

    // Load provider config file

    $.getJSON("/static/json/providers-" + version + ".json", function(data) {
        $.ajax({
            url: "api/provider_check",
            type: "GET",
            success: function(info) {
                $.each(data, function(key, item) {
                    if( info.message.includes(key) ) {
                        $("#provider-selection").append($("<option>", {
                            value: key,
                            id: key,
                            text: item.name + " (already used)",
                            disabled: true
                        }))
                    } else{
                        $("#provider-selection").append($("<option>", {
                            value: key,
                            id: key,
                            text: item.name
                        }))
                    }
                });
            },
            error: function() {
                $.each(data, function(key, item) {
                    $("#provider-selection").append($("<option>", {
                        value: key,
                        id: key,
                        text: item.name
                    }))
                });
            }
        });


        // Hide login and settings card bodies on initial page, remove login attributes

        $(".hide-body").hide();
        $("#access-error").hide();
        $("#verification-error").hide();
        $("#validation-error").hide();
        $("#submission-error").hide();
        $("#login-input").val("");
        $("#password").val("");
        $("#password").prop("disabled", true);
        $("#submit-login-form").prop("disabled", true);
        $(".card").fadeIn(500).prop("hidden", false);
        $("#provider-selection").focus()


        // By pressing enter on the login input field, focus on password input

        $("#login-input").on('keypress',function(e) {
            if(e.which == 13) {
                $("#password").focus()
            }
        });


        // If provider selection is changed, enable/disable account checkbox and show/hide the login card body,
        // reset the login + settings card attributes and enable/disable the manifest attributes

        $("#provider-selection").on("change", function() {
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            $.each(data[selectedProviderId]["manifest_types"], function(key, item) {
                if( item === true ) {
                    $("#" + key).prop("disabled", false);
                } else {
                    $("#" + key).prop("disabled", true);
                }
            });
            $.each( ["1500", "2000", "2999", "3000", "4999", "5000", "8000", "21000"], function(index, item) {
                if( data[selectedProviderId]["available_qualities"].includes(item) ) {
                    $("#" + item).prop("hidden", false).prop("selected", true);
                } else {
                    $("#" + item).prop("hidden", true).prop("selected", false);
                };
            });
            if( data[selectedProviderId]["dd_supported"] ) {
                $(".dd").prop("hidden", false);
            } else {
                $(".dd").prop("hidden", true);
            };
            $("#access-error").slideUp(500);
            $("#verification-error").slideUp(500);
            $("#validation-error").slideUp(500);
            $("#submission-error").slideUp(500);
            $("#login-input").val("");
            $("#password").prop("disabled", true);
            $("#password").val("");
            $("#submit-login-form").prop("disabled", true);
            if( data[this.value].login_required === "0" ) {
                $("#account-check").removeAttr("disabled")
            } else if( data[this.value].login_required === "1" ) {
                $("#account-check").attr("disabled", "disabled")
                $("#account-check").prop("checked", false)
                $("#login-card-header").slideDown(500)
                $("#login-card").prop("style", "border-style: solid;")
            }
            $("#provider-select").prop("disabled", false);
            $("#no-value").prop("disabled", true);
            $("#hls7").prop("selected", true);
            $("#720p50").prop("selected", true);
            $("#A1Stereo1").prop("selected", true);
            $("#A2None").prop("selected", true);
            $(".dd").prop("disabled", false);
            $(".audio").prop("disabled", false);
        });


        // If no account is required, hide the login card body //

        $("#account-check").on("change", function() {
            $("#access-error").slideUp(500);
            if( $("#account-check").is(":checked") ) {
                $("#login-card-header").slideUp(500)
                $("#login-card").prop("style", "border-style: none;")
            } else {
                $("#login-card-header").slideDown(500)
                $("#login-card").prop("style", "border-style: solid;")
            }
        });


        // After selecting the provider, hide provider card body, show login card body (if required)
        // or show settings card body (if login is not required)

        $("#provider-select").click(function() {
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            if( $("#access-error").is(":visible") ) {
                $("#access-error").prop("style", "color: red; opacity: 0.5; margin-top: 3px;");
            }

            // If no account is required to use the service

            if( $("#account-check").is(":checked") ) {
                $("#provider-select").prop("disabled", true);
                $("#provider-selection").prop("disabled", true);
                $("#account-check").prop("disabled", true)
                $.ajax({
                    type: "POST",
                    url: "api/login",
                    datatype: "json",
                    data: {
                        id: selectedProviderId,
                        no_auth: true
                    },
                    success: function(info) {
                        if( info.success === true ) {
                            GoOn();
                            if( $("#access-error").is(":visible") ) {
                                $("#access-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                                $("#access-error").hide()
                            }
                            $("#access-error").slideUp(500);
                        } else {
                            $("#access-error-message").text(info.message);
                            $("#access-error").slideDown(500);
                            $("#access-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                        }
                        $("#provider-select").prop("disabled", false);
                        $("#provider-selection").prop("disabled", false);
                        $("#account-check").prop("disabled", false)
                    },
                    error: function() {
                        $("#access-error-message").text("Failed to retrieve API status");
                        $("#access-error").slideDown(500);
                        $("#access-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                        $("#provider-select").prop("disabled", false);
                        $("#provider-selection").prop("disabled", false);
                        $("#account-check").prop("disabled", false)
                    }
                })
            } else {
                GoOn();
            }
        });

        function GoOn() {

            var selectedProviderName = $("#provider-selection").children("option:selected").text();
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            if( data[selectedProviderId].login_type === "username" ) {
                $("#login-label").text("Username")
                $("#login-input").attr("placeholder", "Enter username")
                $("#login-input").attr("type", "text")
                $("#request-login-code").prop("hidden", true)
                $("#2fa").prop("hidden", true)
                $("#2fa-label").prop("hidden", true)
                $("#password").prop("hidden", false)
                $("#password-label").prop("hidden", false)
            } else if( data[selectedProviderId].login_type === "email" ) {
                $("#login-label").text("Email address")
                $("#login-input").attr("placeholder", "Enter email address")
                $("#login-input").attr("type", "email")
                $("#request-login-code").prop("hidden", true)
                $("#2fa").prop("hidden", true)
                $("#2fa-label").prop("hidden", true)
                $("#password").prop("hidden", false)
                $("#password-label").prop("hidden", false)
            } else if( data[selectedProviderId].login_type === "email_code" ) {
                $("#login-label").text("Email address")
                $("#login-input").attr("placeholder", "Enter email address")
                $("#login-input").attr("type", "email")
                $("#request-login-code").prop("hidden", false)
                $("#2fa").prop("hidden", false)
                $("#2fa-label").prop("hidden", false)
                $("#password").prop("hidden", true)
                $("#password-label").prop("hidden", true)
            } else if( data[selectedProviderId].login_type === "email_pw_code" ) {
                $("#login-label").text("Email address")
                $("#login-input").attr("placeholder", "Enter email address")
                $("#login-input").attr("type", "email")
                $("#request-login-code").prop("hidden", false)
                $("#2fa").prop("hidden", false)
                $("#2fa-label").prop("hidden", false)
                $("#password").prop("hidden", false)
                $("#password-label").prop("hidden", false)
            }
            $("#provider-header").append("selected: " + selectedProviderName);
            $("#go-back-to-provider-card").removeAttr("hidden");
            $("#provider-card-header").removeClass("bg-dark").prop("style", "background-color: #00aa00;");
            $("#provider-link").addClass("stretched-link");
            $("#provider-body").slideUp(500);
            if( $("#account-check").is(":checked") ) {
                $("#settings-body").slideDown(500);
            } else {
                $("#login-body").slideDown(500);
            }
        };


        // Go back to provider selection card by clicking on it

        $("#provider-card-header").click(function() {
            if( $("#provider-link.stretched-link").length ) {
                var selectedProviderName = $("#provider-selection").children("option:selected").text();
                $("#provider-header").text($("#provider-header").text().replace(" selected: " + selectedProviderName, ""));
                $("#go-back-to-provider-card").attr("hidden", "hidden");
                $("#provider-card-header").addClass("bg-dark");
                $("#provider-link").removeClass("stretched-link");
                $("#login-input").prop("disabled", false);
                $("#login-input").val("");
                $("#verification-error").hide();
                $("#validation-error").hide();
                $("#request-login-code").prop("disabled", true);
                $("#request-login-code").text("Request verification code");
                $("#password").prop("disabled", true);
                $("#password").val("");
                $("#2fa").prop("disabled", true);
                $("#2fa").val("");
                if( $("#account-check").is(":checked") ) {
                    $("#settings-body").slideUp(500);
                } else {
                    $("#login-body").slideUp(500);
                }
                $("#provider-body").slideDown(500);
            }
        });


        // If login input value is changed, validate its value

        $("#login-input").on("input", function() {
            $("#verification-error").slideUp(500);
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            if ( $("#login-input").val().length === 0 ) {
                $("#validation-error").slideUp(500);
                $("#request-login-code").prop("disabled", true)
                $("#password").prop("disabled", true);
                $("#submit-login-form").prop("disabled", true);
            } else if ( (/^([+\w-\.]+@([\w-]+\.)+[\w-]{2,6})?$/.test($("#login-input").val()) && (data[selectedProviderId].login_type === "email" || data[selectedProviderId].login_type === "email_code" || data[selectedProviderId].login_type === "email_pw_code" ) ) || ( $("#login-input").val().length > 0 && data[selectedProviderId].login_type === "username" ) ) {
                $("#validation-error").slideUp(500);
                if( data[selectedProviderId].login_type == "email_code" ) {
                    $("#request-login-code").prop("disabled", false);
                };
                if( data[selectedProviderId].login_type != "email_code" ) {
                    $("#password").prop("disabled", false);
                };
                if( $("#password").val().length > 0 && data[selectedProviderId].login_type != "email_pw_code" ) {
                    $("#submit-login-form").prop("disabled", false);
                }
                if( $("#password").val().length > 0 && data[selectedProviderId].login_type == "email_pw_code" ) {
                    $("#request-login-code").prop("disabled", false);
                }
            } else {
                $("#validation-error").slideDown(500);
                $("#password").prop("disabled", true);
                $("#request-login-code").prop("disabled", true);
                $("#submit-login-form").prop("disabled", true);
            }
        });


        // If password entry is changed, enable/disable the submit button

        $("#password").on("input", function() {
            $("#verification-error").slideUp(500)
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            if ( $("#password").val().length === 0 ) {
                if( data[selectedProviderId].login_type != "email_pw_code" ) {
                    $("#submit-login-form").prop("disabled", true)
                } else {
                    $("#request-login-code").prop("disabled", true)
                }
            } else {
                if( data[selectedProviderId].login_type != "email_pw_code" ) {
                    $("#submit-login-form").prop("disabled", false)
                } else {
                    $("#request-login-code").prop("disabled", false)
                }
            }
        });

        $("#2fa").on("input", function() {
            if ( $("#2fa").val().length === 0 ) {
                $("#submit-login-form").prop("disabled", true)
            } else {
                $("#submit-login-form").prop("disabled", false)
            }
        });


        // Get verification code

        $("#request-login-code").click(function() {
            Submit2FARequest();
        });
        
        function Submit2FARequest() {
            $("#verification-error").slideUp(500);
            $("#submit-login-form").prop("disabled", true);
            $("#2fa").val("")
            $("#request-login-code").prop("disabled", true);
            $("#request-login-code").text("Requesting code...");
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            $("#submission-error").slideUp(500);
            $("#provider-link").removeClass("stretched-link");
            $("#go-back-to-provider-card").prop("hidden", true);
            $("#login-input").prop("disabled", true);
            $("#password").prop("disabled", true);
            if( $("#verification-error").is(":visible") ) {
                $("#verification-error").prop("style", "color: red; opacity: 0.5; margin-top: 3px;");
            }
            $.ajax({
                type: "POST",
                url: "api/get_auth_code",
                data: {
                    id: selectedProviderId,
                    login: $("#login-input").val(),
                    pw: $("#password").val()
                },
                datatype: "json",
                success: function(info) {
                    if( info.success === true ) {
                        if( info.verification_not_required === true ) {
                            $("#request-login-code").text("No code required! Please enter the login button.");
                        } else {
                            $("#2fa").prop("disabled", false);
                            $("#request-login-code").text("The code has been requested!");
                        }
                        globalThis.verifyCode = info.token;
                        setTimeout(function() {
                            $("#request-login-code").prop("disabled", false);
                            $("#request-login-code").text("Request verification code");
                        }, 2900);
                    } else {
                        $("#login-input").prop("disabled", false);
                        $("#password").prop("disabled", false);
                        $("#2fa").prop("disabled", true)
                        $("#request-login-code").text("Request verification code");
                        $("#request-login-code").prop("disabled", false);
                        $("#verification-error-message").text(info.message);
                        $("#verification-error").slideDown(500);
                        $("#verification-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                        $("#provider-link").addClass("stretched-link");
                        $("#go-back-to-provider-card").prop("hidden", false);
                    }
                    $("#provider-link").addClass("stretched-link");
                    $("#go-back-to-provider-card").prop("hidden", false);
                },
                error: function() {
                    $("#request-login-code").text("Failed to request the code.");
                    $("#provider-link").addClass("stretched-link");
                    $("#go-back-to-provider-card").prop("hidden", false);
                    $("#verification-error-message").text("Failed to retrieve API status");
                    $("#verification-error").slideDown(500);
                    $("#verification-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                }
            })
        };


        // Verify the account

        $("#submit-login-form").click( function() {
            SubmitForm();
        });

        $("#password").on('keypress', function(e) {
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            if( $("#password").val().length > 0 ) {
                if( e.which == 13 ) {
                    if( data[selectedProviderId].login_type != "email_pw_code" ) {
                        SubmitForm();
                    } else {
                        Submit2FARequest();
                    }
                }
            }
        });

        $("#2fa").on('keypress', function(e) {
            if( $("#2fa").val().length > 0 ) {
                if( e.which == 13 ) {
                    SubmitForm();
                }
            }
        });

        function SubmitForm() {
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            if( data[selectedProviderId].login_type === "email_code" || data[selectedProviderId].login_type === "email_pw_code" ) {
                var pass = btoa(JSON.stringify({"token": verifyCode, "code": $("#2fa").val(), "pw": $("#password").val()}))
            } else {
                var pass = $("#password").val()
            };
            $("#submission-error").slideUp(500);
            $("#provider-link").removeClass("stretched-link");
            $("#go-back-to-provider-card").prop("hidden", true);
            $("#submit-login-form").text("Checking...");
            $("#submit-login-form").prop("disabled", true);
            $("#login-input").prop("disabled", true);
            $("#password").prop("disabled", true);
            $("#2fa").prop("disabled", true);
            $("#request-login-code").prop("disabled", true);
            if( $("#verification-error").is(":visible") ) {
                $("#verification-error").prop("style", "color: red; opacity: 0.5; margin-top: 3px;");
            }
            $.ajax({
                type: "POST",
                url: "api/login",
                data: {
                    id: selectedProviderId,
                    no_auth: false,
                    login: $("#login-input").val(),
                    pw: pass
                },
                datatype: "json",
                success: function(info) {
                    if( info.success === true ) {
                        if( data[selectedProviderId].supports_refresh_token === true ) {
                            globalThis.refresh_token = info.refresh_token;
                        }
                        $("#login-card-header").removeClass("bg-dark").prop("style", "background-color: #00aa00;");
                        $("#login-header").append(" verified: " + info.info.type )
                        $("#go-back-to-login-card").prop("hidden", false);
                        $("#login-link").addClass("stretched-link");
                        $("#login-body").slideUp(500);
                        $("#settings-body").slideDown(500);
                        $("#verification-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                        $("#verification-error").hide();
                    } else {
                        $("#verification-error-message").text(info.message);
                        $("#verification-error").slideDown(500);
                        $("#verification-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                        $("#provider-link").addClass("stretched-link");
                        $("#go-back-to-provider-card").prop("hidden", false);
                    }
                    $("#submit-login-form").text("Submit");
                    $("#submit-login-form").prop("disabled", false);
                    $("#2fa").prop("disabled", false);
                    if( data[selectedProviderId].login_type != "email_pw_code" ) {
                        $("#login-input").prop("disabled", false);
                        $("#password").prop("disabled", false);
                    }
                    $("#request-login-code").prop("disabled", false);
                },
                error: function() {
                    $("#provider-link").addClass("stretched-link");
                    $("#go-back-to-provider-card").prop("hidden", false);
                    $("#verification-error-message").text("Failed to retrieve API status");
                    $("#verification-error").slideDown(500);
                    $("#verification-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                    $("#submit-login-form").text("Submit");
                    $("#submit-login-form").prop("disabled", false);
                    $("#login-input").prop("disabled", false);
                    $("#password").prop("disabled", false);
                }
            })
        };


        // Go back to login card by clicking on it

        $("#login-card-header").click(function() {
            if( $("#login-link.stretched-link").length ) {
                $("#login-card-header").addClass("bg-dark");
                $("#login-header").text("Account");
                $("#settings-body").slideUp(500);
                $("#login-body").slideDown(500);
                $("#go-back-to-login-card").prop("hidden", true)
                $("#login-link").removeClass("stretched-link");
                $("#go-back-to-provider-card").prop("hidden", false)
                $("#provider-link").addClass("stretched-link")
            }
        });


        // If audio type is changed, avoid duplicated entries

        $("#A1").on("change", function() {
            if( $("#A1").val() === $("#A2").val() ) {
                $("#A2None").prop("selected", true)
            }
        });

        $("#A2").on("change", function() {
            if( $("#A1").val() === $("#A2").val() ) {
                if( $("#A2").val() === "aac1" ) {
                    $("#A1Stereo2").prop("selected", true)
                } else {
                    $("#A1Stereo1").prop("selected", true)
                }
            }
        });


        // If manifest type is changed, also change the available audio profiles

        $("#manifest-selection").on("change", function() {
            if( $("#manifest-selection").val() === "hls5" ) {
                if( $("#A1").val() === "dd1" ) {
                    if( $("#A2").val() === "aac1" ) {
                        $("#A1Stereo2").prop("selected", true)
                    } else {
                        $("#A1Stereo1").prop("selected", true)
                    }
                }
                if( $("#A2").val() === "dd1" ) {
                    if( $("#A1").val() === "aac1" ) {
                        $("#A2None").prop("selected", true)
                    } else {
                        $("#A2Stereo1").prop("selected", true)
                    }
                }
                $(".audio").prop("disabled", false);
                $(".dd").prop("disabled", true);
            } else if( $("#manifest-selection").val() === "hls7" ) {
                $(".audio").prop("disabled", false);
                $(".dd").prop("disabled", false);
            }
        });


        // Finally submit all login and settings data to create the TV setup

        $("#submit-provider-form").click( function() {
            var selectedProviderId = $("#provider-selection").children("option:selected").val();
            if( $("#account-check").is(":checked") ) {
                $("#provider-link").removeClass("stretched-link");
                $("#go-back-to-provider-card").prop("hidden", true);
            } else {
                $("#login-link").removeClass("stretched-link");
                $("#go-back-to-login-card").prop("hidden", true);
            }
            if( $("#submission-error").is(":visible") ) {
                $("#submission-error").prop("style", "color: red; opacity: 0.5; margin-top: 3px;");
            }
            $("#submit-provider-form").text("Checking...");
            $("#submit-provider-form").prop("disabled", true);
            $("#manifest-selection").prop("disabled", true);
            $("#bw-selection").prop("disabled", true);
            $("#A1").prop("disabled", true);
            $("#A2").prop("disabled", true);
            if( data[selectedProviderId].supports_refresh_token === true && !$("#account-check").is(":checked")) {
                var a_pw = null;
                var a_rt = refresh_token;
            } else {
                var a_pw = $("#password").val();
                var a_rt = null;
            };
            $.ajax({
                type: "POST",
                url: "api/new",
                datatype: "json",
                data: {
                    id: selectedProviderId,
                    login: $("#login-input").val(),
                    pw: a_pw,
                    rt: a_rt,
                    no_auth: $("#account-check").is(":checked"),
                    manifest_type: $("#manifest-selection").children("option:selected").val(),
                    bw: $("#bw-selection").children("option:selected").val(),
                    audio1: $("#A1").children("option:selected").val(),
                    audio2: $("#A2").children("option:selected").val()
                },
                success: function(data) {
                    if(data.success) {
                        $("#submit-provider-form").text("Done!");
                        $("#settings-card").attr("style", "margin-bottom: 0px;");
                        $("#settings-card-header").append(" saved");
                        $("#settings-card-header").removeClass("bg-dark").prop("style", "background-color: #00aa00;");
                        $("#settings-body").slideUp(500);
                        $("#account-accepted-info").prop("hidden", false);
                        $(".how-to-continue").fadeIn(1500);
                        window.setTimeout( function() {
                            window.location = "/";
                        }, 2000);
                    } else {
                        $("#submission-error-message").text(data.message);
                        $("#submission-error").slideDown(500);
                        $("#submission-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                        if( $("#account-check").is(":checked") ) {
                            $("#provider-link").addClass("stretched-link");
                            $("#go-back-to-provider-card").prop("hidden", false);
                        } else {
                            $("#login-link").addClass("stretched-link");
                            $("#go-back-to-login-card").prop("hidden", false);
                        }
                        $("#submit-provider-form").text("Add TV setup");
                        $("#submit-provider-form").prop("disabled", false);
                        $("#manifest-selection").prop("disabled", false);
                        $("#bw-selection").prop("disabled", false);
                        $("#A1").prop("disabled", false);
                        $("#A2").prop("disabled", false);
                    }
                },
                error: function() {
                    $("#submission-error-message").text("Unable to retrieve API status");
                    $("#submission-error").slideDown(500);
                    $("#submission-error").prop("style", "color: red; opacity: 1; margin-top: 3px;");
                    if( $("#account-check").is(":checked") ) {
                        $("#provider-link").addClass("stretched-link");
                        $("#go-back-to-provider-card").prop("hidden", false);
                    } else {
                        $("#login-link").addClass("stretched-link");
                        $("#go-back-to-login-card").prop("hidden", false);
                    }
                    $("#submit-provider-form").text("Add TV setup");
                    $("#submit-provider-form").prop("disabled", false);
                    $("#manifest-selection").prop("disabled", false);
                    $("#bw-selection").prop("disabled", false);
                    $("#A1").prop("disabled", false);
                    $("#A2").prop("disabled", false);
                }
            })
        });
    });
});