$(document).ready(function() {

    // Change root location
    $("#go-to-home").prop("href", window.location.href.replace(new RegExp('/signup$'), ""));

    $(".verification-error").hide()
    $(".card").fadeIn(500).prop("hidden", false)
    $(".first-input").focus()

    $("#signup-password").on("input", function() {
        if( $("#signup-password").val().length >= 8 && $("#signup-password-confirm").val().length >= 8 ) {
            $("#submit-signup-form").prop("disabled", false)
        } else {
            $("#submit-signup-form").prop("disabled", true)
        }
    });

    $("#signup-password-confirm").on("input", function() {
        if( $("#signup-password").val().length >= 8 && $("#signup-password-confirm").val().length >= 8 && $("#signup-password").val() === $("#signup-password-confirm").val() ) {
            $("#submit-signup-form").prop("disabled", false)
        } else {
            $("#submit-signup-form").prop("disabled", true)
        }
    });
    $("#signup-password-confirm").on("keypress", function(e) {
        if(e.which == 13 && $("#signup-password").val().length >= 8 && $("#signup-password-confirm").val().length >= 8 && $("#signup-password").val() === $("#signup-password-confirm").val() ) {
            GoOn()
        }
    });

    $("#signup-password").on("keypress", function(e) {
        if( $("#signup-password").val().length > 0 ) {
            if(e.which == 13) {
                $("#signup-password-confirm").focus()
            }
        }
    });

    $("#submit-signup-form").on("click", function() {
        GoOn()
    });

    function GoOn() {

        $("#submit-signup-form").prop("disabled", true)
        $("#submit-signup-form").text("Checking...")
        if( !$(".verification-error").is(":hidden") ) {
            $(".verification-error").prop("style", "margin-top: 3px; color: red; opacity: 0.5")
        }
        $.ajax({
            type: "POST",
            url: "api/signup_check",
            data: {
                pw: $("#signup-password").val()
            },
            datatype: "json",
            success: function(info) {
                if( info.success === true ) {
                    window.location.href = "setup"
                } else {
                    $("#submit-signup-form").text('Sign Up')
                    $("#submit-signup-form").prop("disabled", false)
                    $(".verification-error-message").text(info.message)
                    if( $(".verification-error").is(":hidden") ) {
                        $(".verification-error").prop("hidden", false).slideDown(500)
                    } else {
                        $(".verification-error").prop("style", "margin-top: 3px; color: red; opacity: 1")
                    }
                }
            },
            error: function(info) {
                $("#submit-signup-form").text("Sign Up")
                $("#submit-signup-form").prop("disabled", false)
                $(".verification-error-message").text("Failed to retrieve API status")
                if( $(".verification-error").is(":hidden") ) {
                    $(".verification-error").prop("hidden", false).slideDown(500)
                } else {
                    $(".verification-error").prop("style", "margin-top: 3px; color: red; opacity: 1")
                }
            }
        });
    };
});